# Don't Remove Credit Tg - @VJ_Botz
# Subscribe YouTube Channel For Amazing Bot https://youtube.com/@Tech_VJ
# Ask Doubt on telegram @KingVJ01

from os import environ

API_ID = int(environ.get("API_ID", "20891424"))
API_HASH = environ.get("API_HASH", "f29cef7feff53b2d9321c6b9e5d69b21")
BOT_TOKEN = environ.get("BOT_TOKEN", "7215883975:AAEK-lOVgRuQh_ANuwhdNTro7BZTIdzQ0B8")
